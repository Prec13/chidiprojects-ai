# ChidiProjects AI

This is a simple React app for generating mathematics project outlines and solutions.

### Features
- Accepts project topics related to mathematics
- Returns equations, proofs, and derivations using LaTeX rendering
- Built with React and KaTeX

### Scripts
- `npm start` → start dev server
- `npm run build` → production build
