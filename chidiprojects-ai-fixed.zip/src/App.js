import React, { useState } from "react";
import { InlineMath, BlockMath } from "react-katex";
import "katex/dist/katex.min.css";
import "./App.css";

function App() {
  const [topic, setTopic] = useState("");
  const [answer, setAnswer] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (topic.toLowerCase().includes("integration")) {
      setAnswer("∫ x dx = (x^2)/2 + C");
    } else if (topic.toLowerCase().includes("differentiation")) {
      setAnswer("d/dx (x^2) = 2x");
    } else {
      setAnswer("This project topic is not recognized yet. Please try another.");
    }
  };

  return (
    <div className="App">
      <h1>ChidiProjects AI</h1>
      <p>Mathematics Project Assistant</p>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="Enter your project topic"
        />
        <button type="submit">Generate</button>
      </form>
      {answer && (
        <div className="answer">
          <BlockMath math={answer} />
        </div>
      )}
    </div>
  );
}

export default App;
